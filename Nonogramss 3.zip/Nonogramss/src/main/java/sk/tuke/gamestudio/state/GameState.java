package sk.tuke.gamestudio.state;

public enum GameState {
    PLAYING,
    SOLVED
}


